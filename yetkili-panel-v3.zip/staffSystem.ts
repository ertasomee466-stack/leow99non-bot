import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelType,
  ChatInputCommandInteraction,
  EmbedBuilder,
  Guild,
  GuildMember,
  Interaction,
  PermissionFlagsBits,
  SlashCommandBuilder,
  type GuildTextBasedChannel,
  type Role,
} from "discord.js";
import fs from "node:fs";
import path from "node:path";

/* =========================================================
   YETKİLİ NUMARA + GÖREV SİSTEMİ
========================================================= */

const DATA_DIRECTORY = path.resolve(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIRECTORY, "staff-system.json");

const DEFAULT_START_NUMBER = 1;

const STAFF_ROLE_NAME = "Yetkili";
const DUTY_ROLE_NAME = "Görevde";

const CATEGORY_NAME = "YETKİLİ SİSTEMİ";
const PANEL_CHANNEL_NAME = "yetkili-panel";

const NUMBER_BUTTON_ID = "staff:number";
const DUTY_BUTTON_ID = "staff:duty";

interface GuildStaffSettings {
  staffRoleId: string;
  dutyRoleId: string;
  panelChannelId?: string;
  logChannelId?: string;
  nextNumber: number;
  assignments: Record<string, number>;
}

interface StaffDatabase {
  guilds: Record<string, GuildStaffSettings>;
}

let database: StaffDatabase = loadDatabase();

/* =========================================================
   VERİTABANI
========================================================= */

function loadDatabase(): StaffDatabase {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      return { guilds: {} };
    }

    const parsed = JSON.parse(
      fs.readFileSync(DATA_FILE, "utf8"),
    ) as Partial<StaffDatabase>;

    return {
      guilds:
        parsed.guilds && typeof parsed.guilds === "object"
          ? parsed.guilds
          : {},
    };
  } catch (error) {
    console.error("❌ Yetkili sistemi veritabanı okunamadı:", error);
    return { guilds: {} };
  }
}

function saveDatabase(): void {
  try {
    fs.mkdirSync(DATA_DIRECTORY, { recursive: true });

    fs.writeFileSync(
      DATA_FILE,
      JSON.stringify(database, null, 2),
      "utf8",
    );
  } catch (error) {
    console.error("❌ Yetkili sistemi veritabanı kaydedilemedi:", error);
  }
}

function getSettings(guildId: string): GuildStaffSettings | undefined {
  return database.guilds[guildId];
}

/* =========================================================
   İSİM YARDIMCILARI
========================================================= */

function stripNumber(name: string): string {
  return name.replace(/^\[\d+\]\s*-\s*/u, "").trim() || "Yetkili";
}

function createNickname(number: number, name: string): string {
  const prefix = `[${number}] - `;
  const maximumNameLength = Math.max(1, 32 - prefix.length);

  return `${prefix}${stripNumber(name).slice(0, maximumNameLength)}`;
}

function getBaseName(member: GuildMember): string {
  return stripNumber(
    member.nickname ??
      member.user.globalName ??
      member.user.username,
  );
}

/* =========================================================
   KANAL VE ROL YARDIMCILARI
========================================================= */

async function getSendableChannel(
  guild: Guild,
  channelId: string,
): Promise<GuildTextBasedChannel | null> {
  const channel = await guild.channels.fetch(channelId).catch(() => null);

  if (!channel || !channel.isTextBased()) {
    return null;
  }

  return channel as GuildTextBasedChannel;
}

async function findOrCreateRole(
  guild: Guild,
  name: string,
  reason: string,
): Promise<Role> {
  await guild.roles.fetch();

  const existing = guild.roles.cache.find(
    (role) =>
      role.name.toLocaleLowerCase("tr-TR") ===
      name.toLocaleLowerCase("tr-TR"),
  );

  if (existing) {
    return existing;
  }

  return guild.roles.create({
    name,
    reason,
  });
}

/* =========================================================
   PANEL
========================================================= */

function createPanelPayload() {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("Yetkili İşlem Paneli")
    .setDescription(
      [
        "Aşağıdaki butonlardan yapmak istediğin işlemi seç.",
        "",
        "🔢 **Numaramı Al**",
        "Sana sıradaki yetkili numarasını verir.",
        "İsmin `[1] - Kullanıcı Adı` şeklinde düzenlenir.",
        "",
        "📋 **Görev Al**",
        "Görevde rolünü alırsın.",
        "Butona tekrar basarsan görev rolün kaldırılır.",
      ].join("\n"),
    )
    .setFooter({
      text: "Her yetkili yalnızca bir numara alabilir.",
    });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(NUMBER_BUTTON_ID)
      .setLabel("Numaramı Al")
      .setEmoji("🔢")
      .setStyle(ButtonStyle.Success),

    new ButtonBuilder()
      .setCustomId(DUTY_BUTTON_ID)
      .setLabel("Görev Al")
      .setEmoji("📋")
      .setStyle(ButtonStyle.Primary),
  );

  return {
    embeds: [embed],
    components: [row],
  };
}

async function sendOrRefreshPanel(
  guild: Guild,
  channelId: string,
): Promise<void> {
  const channel = await getSendableChannel(guild, channelId);

  if (!channel) {
    throw new Error("Yetkili panel kanalı kullanılamıyor.");
  }

  const recentMessages = await channel.messages
    .fetch({ limit: 25 })
    .catch(() => null);

  const oldPanel = recentMessages?.find(
    (message) =>
      message.author.id === guild.client.user?.id &&
      message.components.some((row) =>
        row.components.some(
          (component) =>
            "customId" in component &&
            component.customId === NUMBER_BUTTON_ID,
        ),
      ),
  );

  if (oldPanel) {
    await oldPanel.edit(createPanelPayload());
    return;
  }

  await channel.send(createPanelPayload());
}

/* =========================================================
   /KURULUM İÇİN OTOMATİK KURULUM
========================================================= */

export async function ensureStaffSystemSetup(
  guild: Guild,
): Promise<GuildStaffSettings> {
  const botMember = guild.members.me;

  if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles)) {
    throw new Error("Botta Rolleri Yönet yetkisi yok.");
  }

  if (!botMember.permissions.has(PermissionFlagsBits.ManageChannels)) {
    throw new Error("Botta Kanalları Yönet yetkisi yok.");
  }

  const staffRole = await findOrCreateRole(
    guild,
    STAFF_ROLE_NAME,
    "Yetkili sistemi kurulumu",
  );

  const dutyRole = await findOrCreateRole(
    guild,
    DUTY_ROLE_NAME,
    "Yetkili görev sistemi kurulumu",
  );

  let category = guild.channels.cache.find(
    (channel) =>
      channel.type === ChannelType.GuildCategory &&
      channel.name === CATEGORY_NAME,
  );

  if (!category) {
    category = await guild.channels.create({
      name: CATEGORY_NAME,
      type: ChannelType.GuildCategory,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: staffRole.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ],
      reason: "Yetkili sistemi kurulumu",
    });
  }

  let panelChannel = guild.channels.cache.find(
    (channel) =>
      channel.type === ChannelType.GuildText &&
      channel.name === PANEL_CHANNEL_NAME,
  );

  if (!panelChannel) {
    panelChannel = await guild.channels.create({
      name: PANEL_CHANNEL_NAME,
      type: ChannelType.GuildText,
      parent: category.id,
      topic: "Yetkili numarası ve görev alma paneli",
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: staffRole.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.ReadMessageHistory,
          ],
          deny: [PermissionFlagsBits.SendMessages],
        },
      ],
      reason: "Yetkili sistemi kurulumu",
    });
  }

  const previous = getSettings(guild.id);

  const settings: GuildStaffSettings = {
    staffRoleId: staffRole.id,
    dutyRoleId: dutyRole.id,
    panelChannelId: panelChannel.id,
    logChannelId: previous?.logChannelId,
    nextNumber: previous?.nextNumber ?? DEFAULT_START_NUMBER,
    assignments: previous?.assignments ?? {},
  };

  database.guilds[guild.id] = settings;
  saveDatabase();

  await sendOrRefreshPanel(guild, panelChannel.id);

  return settings;
}

/* =========================================================
   SLASH KOMUTLARI
========================================================= */

export const staffSystemCommands = [
  new SlashCommandBuilder()
    .setName("yetkili-ayar")
    .setDescription("Yetkili numara sistemini ayarlar.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addRoleOption((option) =>
      option
        .setName("yetkili-rolu")
        .setDescription("Paneli kullanabilecek yetkili rolü.")
        .setRequired(true),
    )
    .addIntegerOption((option) =>
      option
        .setName("baslangic-numarasi")
        .setDescription("İlk numara. Boş bırakılırsa 1.")
        .setMinValue(1)
        .setMaxValue(999_999),
    )
    .addChannelOption((option) =>
      option
        .setName("log-kanali")
        .setDescription("Numara işlemlerinin gönderileceği kanal.")
        .addChannelTypes(
          ChannelType.GuildText,
          ChannelType.GuildAnnouncement,
        ),
    ),

  new SlashCommandBuilder()
    .setName("yetkili-panel")
    .setDescription("Yetkili işlem panelini kurar veya yeniler.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
];

/* =========================================================
   KOMUT İŞLEYİCİLERİ
========================================================= */

async function handleSettings(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  if (
    !interaction.inGuild() ||
    !interaction.guild ||
    !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)
  ) {
    await interaction.reply({
      content: "❌ Bu komut için Sunucuyu Yönet yetkisi gerekir.",
      ephemeral: true,
    });
    return;
  }

  const staffRole = interaction.options.getRole("yetkili-rolu", true);
  const startNumber =
    interaction.options.getInteger("baslangic-numarasi") ??
    DEFAULT_START_NUMBER;
  const logChannel = interaction.options.getChannel("log-kanali");

  const dutyRole = await findOrCreateRole(
    interaction.guild,
    DUTY_ROLE_NAME,
    "Yetkili görev sistemi ayarı",
  );

  const previous = getSettings(interaction.guildId);

  database.guilds[interaction.guildId] = {
    staffRoleId: staffRole.id,
    dutyRoleId: dutyRole.id,
    panelChannelId: previous?.panelChannelId,
    logChannelId: logChannel?.id ?? previous?.logChannelId,
    nextNumber:
      previous && Object.keys(previous.assignments).length > 0
        ? previous.nextNumber
        : startNumber,
    assignments: previous?.assignments ?? {},
  };

  saveDatabase();

  await interaction.reply({
    content: [
      "✅ Yetkili sistemi ayarlandı.",
      `Yetkili rolü: ${staffRole}`,
      `Görev rolü: ${dutyRole}`,
      `Sıradaki numara: **${database.guilds[interaction.guildId].nextNumber}**`,
    ].join("\n"),
    ephemeral: true,
  });
}

async function handlePanel(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  if (
    !interaction.inGuild() ||
    !interaction.guild ||
    !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)
  ) {
    await interaction.reply({
      content: "❌ Bu komut için Sunucuyu Yönet yetkisi gerekir.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const settings = await ensureStaffSystemSetup(interaction.guild);

  await interaction.editReply(
    `✅ Panel hazırlandı: <#${settings.panelChannelId}>`,
  );
}

/* =========================================================
   NUMARA BUTONU
========================================================= */

async function handleNumberButton(
  interaction: ButtonInteraction,
): Promise<void> {
  if (!interaction.guild || !interaction.guildId) {
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const settings = getSettings(interaction.guildId);

  if (!settings) {
    await interaction.editReply(
      "❌ Sistem ayarlanmamış. Yönetici `/kurulum` komutunu kullanmalı.",
    );
    return;
  }

  const member = await interaction.guild.members
    .fetch(interaction.user.id)
    .catch(() => null);

  if (!member) {
    await interaction.editReply("❌ Üyelik bilgin alınamadı.");
    return;
  }

  if (!member.roles.cache.has(settings.staffRoleId)) {
    await interaction.editReply(
      "❌ Yetkili rolüne sahip olmadığın için numara alamazsın.",
    );
    return;
  }

  const existingNumber = settings.assignments[member.id];

  if (existingNumber !== undefined) {
    await interaction.editReply(
      `ℹ️ Zaten **${existingNumber}** numarasına sahipsin.`,
    );
    return;
  }

  if (!member.manageable) {
    await interaction.editReply(
      [
        "❌ Bot takma adını değiştiremiyor.",
        "Bot rolünü Yetkili rolünün üstüne taşı.",
        "Bota Takma Adları Yönet yetkisi ver.",
      ].join("\n"),
    );
    return;
  }

  const number = settings.nextNumber;
  const nickname = createNickname(number, getBaseName(member));

  await member.setNickname(
    nickname,
    `Yetkili numarası verildi: ${number}`,
  );

  settings.assignments[member.id] = number;
  settings.nextNumber = number + 1;
  saveDatabase();

  if (settings.logChannelId) {
    const logChannel = await getSendableChannel(
      interaction.guild,
      settings.logChannelId,
    );

    await logChannel
      ?.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0x57f287)
            .setTitle("Yetkili numarası verildi")
            .setDescription(
              `${member} kullanıcısına **${number}** numarası verildi.`,
            )
            .setTimestamp(),
        ],
      })
      .catch(() => null);
  }

  await interaction.editReply(
    `✅ Numaran **${number}** oldu.\nYeni ismin: **${member.displayName}**`,
  );
}

/* =========================================================
   GÖREV AL BUTONU
========================================================= */

async function handleDutyButton(
  interaction: ButtonInteraction,
): Promise<void> {
  if (!interaction.guild || !interaction.guildId) {
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const settings = getSettings(interaction.guildId);

  if (!settings) {
    await interaction.editReply(
      "❌ Sistem ayarlanmamış. Yönetici `/kurulum` komutunu kullanmalı.",
    );
    return;
  }

  const member = await interaction.guild.members
    .fetch(interaction.user.id)
    .catch(() => null);

  if (!member) {
    await interaction.editReply("❌ Üyelik bilgin alınamadı.");
    return;
  }

  if (!member.roles.cache.has(settings.staffRoleId)) {
    await interaction.editReply(
      "❌ Yetkili rolüne sahip olmadığın için görev alamazsın.",
    );
    return;
  }

  const dutyRole = await interaction.guild.roles
    .fetch(settings.dutyRoleId)
    .catch(() => null);

  if (!dutyRole) {
    await interaction.editReply(
      "❌ Görevde rolü bulunamadı. Yönetici `/kurulum` komutunu tekrar kullanmalı.",
    );
    return;
  }

  if (!dutyRole.editable) {
    await interaction.editReply(
      "❌ Bot Görevde rolünü veremiyor. Bot rolünü Görevde rolünün üstüne taşı.",
    );
    return;
  }

  if (member.roles.cache.has(dutyRole.id)) {
    await member.roles.remove(
      dutyRole,
      "Yetkili görevden çıktı.",
    );

    await interaction.editReply(
      "✅ Görevden çıktın. **Görevde** rolün kaldırıldı.",
    );
    return;
  }

  await member.roles.add(
    dutyRole,
    "Yetkili görev aldı.",
  );

  await interaction.editReply(
    "✅ Görev aldın. **Görevde** rolün verildi.",
  );
}

/* =========================================================
   INTERACTION YÖNETİCİSİ
========================================================= */

export async function handleStaffSystemInteraction(
  interaction: Interaction,
): Promise<boolean> {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === "yetkili-ayar") {
      await handleSettings(interaction);
      return true;
    }

    if (interaction.commandName === "yetkili-panel") {
      await handlePanel(interaction);
      return true;
    }
  }

  if (!interaction.isButton()) {
    return false;
  }

  if (interaction.customId === NUMBER_BUTTON_ID) {
    await handleNumberButton(interaction);
    return true;
  }

  if (interaction.customId === DUTY_BUTTON_ID) {
    await handleDutyButton(interaction);
    return true;
  }

  return false;
}
